﻿/**
 * \file Form1.cs
 * \author Nedim Can Hüray
 * \date 09/12/2023
 * 
 * \brief This file contains the implementation of a 3x3 puzzle game.
 * 
 * This puzzle game is a simple 3x3 grid of buttons, numbered from 1 to 8, with one empty space.
 * The goal of the game is to arrange the buttons in one of two ways:
 * 1. In consecutive order from 1 to 8, with the empty space at the end.
 * 2. In consecutive order from 1 to 8 in an anticlockwise circle, with the empty space in the middle.
 * 
 * The player can move a number to the empty space if they are adjacent horizontally or vertically.
 * The game checks for a win after each move.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace PuzzleGameAssignment_NEDIM
{
    public partial class Form1 : Form
    {
        //vars
        int row, col;
        static int moveNum = 0;

        // Create a list of numbers 1 to 8
        List<int> numbers = Enumerable.Range(1, 9).ToList();
        //button array 
        Button[,] buttons;

        //add form
        

        public Form1()
        {
            InitializeComponent();
            newGame();
            buttons = new Button[3, 3] { {button1, button2, button3 },
                { button6, button5, button4 }, { button9, button8, button7 } };
            
        }

        //Game initializer
        private void newGame()
        {
            //Button array
            Button[,] buttons = new Button[3, 3] { {button1, button2, button3 },
                { button6, button5, button4 }, { button9, button8, button7 } };

            // Shuffle the list
            Random rng = new Random();
            int n = numbers.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                int temp = numbers[k];
                numbers[k] = numbers[n];
                numbers[n] = temp;
            }
            // Assign the shuffled numbers to the first 8 buttons
            int count = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    buttons[i, j].Text = numbers[count].ToString();
                    if (buttons[i, j].Text == "9")
                        buttons[i, j].Text = " ";
                    count++;
                }
            }
        }

        private bool isSolved()
        {
            // Winning condition 1: numbers in consecutive order from 1 to 8, with the empty space at the end
            int[] linearOrder = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 0 };

            // Winning condition 2: numbers in consecutive order from 1 to 8 in an anticlockwise circle, with the empty space in the middle
            int[] circularOrder = new int[] { 1, 2, 3, 8, 0, 4, 7, 6, 5 };

            // Create an array to hold the current order of numbers
            int[] currentOrder = new int[9];

            // Fill the currentOrder array with the numbers from the buttons
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    currentOrder[i * 3 + j] = buttons[i, j].Text == " " ? 0 : int.Parse(buttons[i, j].Text);
                }
            }

            // Check if the current order of numbers matches either of the winning conditions
            if (currentOrder.SequenceEqual(linearOrder) || currentOrder.SequenceEqual(circularOrder))
            {
                return true;
            }

            return false;
        }

        //Finds the position of the given button on the button array
        private void findPosition(Control b, ref int row, ref int col)
        {
            for(int i=0; i < 3; ++i)
            {
                for(int j = 0; j < 3; j++)
                {
                    if(b.Text == buttons[i, j].Text)
                    {
                        //ref values
                        row = i; 
                        col = j;
                    }
                }
            }
        }

        private void moveNumber(Control b)
        {
            findPosition(b, ref row, ref col);

            // Check the button above
            if (row > 0 && buttons[row - 1, col].Text == " ")
            {
                buttons[row - 1, col].Text = b.Text;
                b.Text = " ";
                moveNum++;
            }
            // Check the button below
            else if (row < 2 && buttons[row + 1, col].Text == " ")
            {
                buttons[row + 1, col].Text = b.Text;
                b.Text = " ";
                moveNum++;
            }
            // Check the button to the left
            else if (col > 0 && buttons[row, col - 1].Text == " ")
            {
                buttons[row, col - 1].Text = b.Text;
                b.Text = " ";
                moveNum++;
            }
            // Check the button to the right
            else if (col < 2 && buttons[row, col + 1].Text == " ")
            {
                buttons[row, col + 1].Text = b.Text;
                b.Text = " ";
                moveNum++;
            }

           if (isSolved())
            {
                //anotherform
                MessageBox.Show("Congrats you won!!");
                newGame();
            }

        }

        //Exit
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //New Game
        private void buttonNG_Click(object sender, EventArgs e)
        {
            newGame();
            //restart the move count
            moveNum = 0;
            label2.Text = "Move #" + moveNum.ToString();
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.buttonNG_Click(sender, e);
        }

        //level selection
        private void beginnerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            beginnerToolStripMenuItem.Checked = true;
            advanceToolStripMenuItem.Checked = false;
        }

        //Moves
        private void button5_Click_1(object sender, EventArgs e)
        {
            moveNumber(button5);
            label2.Text = "Move #"+moveNum.ToString();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            moveNumber(button2);
            label2.Text = "Move #"+moveNum.ToString();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            moveNumber(button3);
            label2.Text = "Move #"+moveNum.ToString();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            moveNumber(button6);
            label2.Text = "Move #"+moveNum.ToString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            moveNumber(button1);
            label2.Text = "Move #"+moveNum.ToString();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            moveNumber(button4);
            label2.Text = "Move #"+moveNum.ToString();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            moveNumber(button9);
            label2.Text = "Move #"+moveNum.ToString();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            moveNumber(button8);
            label2.Text = "Move #"+moveNum.ToString();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            moveNumber(button7);
            label2.Text = "Move #"+moveNum.ToString();
        }

        //About box
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 aboutBox1 = new AboutBox1();
            aboutBox1.Show();   
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1 = new ColorDialog();
            colorDialog1.ShowDialog();
            this.BackColor = colorDialog1.Color;
            
        }

        //For color changes
        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Green;
        }

        private void whiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
        }

        private void blackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Black;
        }

        private void advanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            advanceToolStripMenuItem.Checked = true;
            beginnerToolStripMenuItem.Checked = false;
        }
    }
}
